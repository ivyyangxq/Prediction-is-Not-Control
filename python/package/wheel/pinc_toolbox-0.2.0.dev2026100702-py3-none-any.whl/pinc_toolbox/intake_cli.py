"""Interactive intake for a PINC monitoring request.

The wizard only collects and validates environment metadata.  A host runner
then consumes the emitted JSON and executes the shared detector; no internal
branch or cutoff is exposed as a user setting.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .model_adapter import DetectorConfig, EnvironmentSpec, ReleasedData, validate_environment


def _ask(prompt: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default is not None else ""
    value = input(prompt + suffix + ": ").strip()
    return value if value else (default or "")


def _csv_names(value: str) -> tuple[str, ...]:
    names = tuple(x.strip() for x in value.split(",") if x.strip())
    if not names:
        raise ValueError("at least one column is required")
    return names


def interactive_request() -> dict[str, Any]:
    state = _csv_names(_ask("Public state columns (comma separated)"))
    action_raw = _ask("Executed action column; type none for actionless G-only", "action")
    action = None if action_raw.lower() in {"none", "null", "-"} else action_raw
    reward = _ask("Observed reward column", "reward")
    next_state = _csv_names(_ask("Next-state columns (comma separated)"))
    release = _ask("Outcome release-date column", "release_date")
    decision = _ask("Decision-date column", "decision_date")
    hidden_raw = _ask("Hidden columns (comma separated; blank if none)", "")
    hidden = tuple(x.strip() for x in hidden_raw.split(",") if x.strip())
    q_applicable = _ask("Is an economic action/Q branch applicable? (y/n)", "y").lower() in {"y", "yes"}
    grid_raw = _ask("Action grid (comma separated; blank for G-only)", "0,0.09,0.18")
    grid = () if not grid_raw.strip() else tuple(float(x.strip()) for x in grid_raw.split(","))
    eta = _ask("Eta", "2")
    fit_window = int(_ask("G fit window", "64"))
    monitoring_window = int(_ask("Monitoring window", "8"))
    q_mode = _ask("Q mode (none/finite/infinite)", "finite" if q_applicable else "none").lower()
    q_horizon = None if q_mode != "finite" else int(_ask("Finite Q horizon", "10"))
    table_path = Path(_ask("Released data JSON path"))
    table = json.loads(table_path.read_text())
    spec = EnvironmentSpec(state=state, action=action, reward=reward, next_state=next_state,
                           release_date=release, decision_date=decision, hidden=hidden,
                           q_applicable=q_applicable, action_is_structural=q_applicable)
    data = ReleasedData(table=table, action_grid=grid)
    config = DetectorConfig(eta=eta, fit_window=fit_window, monitoring_window=monitoring_window,
                            q_mode=q_mode, q_horizon=q_horizon)
    report = validate_environment(spec, data, config)
    report["data_json"] = str(table_path)
    report["perceived_model"] = "provided_to_host_runner"
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PINC environment intake")
    parser.add_argument("--interactive", action="store_true", help="ask for the environment fields")
    parser.add_argument("--output", type=Path, help="write the validated intake JSON")
    args = parser.parse_args(argv)
    if not args.interactive:
        parser.error("use --interactive")
    report = interactive_request()
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
