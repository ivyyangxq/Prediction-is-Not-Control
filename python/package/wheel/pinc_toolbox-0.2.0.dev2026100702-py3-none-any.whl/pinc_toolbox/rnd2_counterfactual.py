"""Released-history RA-GQ adapter using the installed RND2 G/Q implementation.

Auxiliary definitions are extracted from RND2 simple_adapter.common_deltas:
RMS change of both physical response coordinates on common action/reference
support; RMS first-physical reference-motion change; preissued base-G error.
No HS economic equations, latent state or independent planner are used.
"""
from __future__ import annotations
from copy import deepcopy
import numpy as np
import pandas as pd
from .counterfactual import PublicState, _date
from .native_gq import RND2GQ, GRID, XCOL, _fit_model, _positive_integer
from .g import SupportError


def common_rnd2_deltas(old, new):
    """Use up to27 sorted actual common-reference probes, as in RND2 core."""
    probes = (pd.concat([old._train_frame, new._train_frame], ignore_index=True)
              [XCOL].drop_duplicates().sort_values(XCOL, kind='mergesort').to_numpy(float))
    eligible = np.ones(len(probes), bool)
    def masks(model, x):
        support = model.support_
        distances, ids = support.search.kneighbors(support.standardize(x))
        local = support.actions[ids]
        low, high = np.quantile(local, [.025, .975], axis=1)
        inside = distances[:, -1] <= support.distance_limit
        anchor = inside & (x[:, 2] >= low) & (x[:, 2] <= high)
        cells = inside[:, None] & (GRID >= low[:, None]) & (GRID <= high[:, None])
        return cells, anchor
    for model in (old, new):
        eligible &= masks(model, probes)[1]
    probes = probes[eligible]
    if not len(probes):
        raise SupportError('no common supported RND2 reference probes')
    probes = probes[np.linspace(0, len(probes)-1, min(27, len(probes)), dtype=int)]
    om, oa = masks(old, probes); nm, na = masks(new, probes)
    cells = om & nm & (oa & na)[:, None]
    if not cells.any():
        raise SupportError('no common supported RND2 action/reference pairs')
    x = np.repeat(probes, len(GRID), axis=0); actions = np.tile(GRID, len(probes))
    old_a = old.transition_.predict(x, actions)[:, :2]
    new_a = new.transition_.predict(x, actions)[:, :2]
    old_r = old.transition_.predict(x, x[:, 2])[:, :2]
    new_r = new.transition_.predict(x, x[:, 2])[:, :2]
    gamma = float(np.sqrt(np.mean(((new_a-new_r)-(old_a-old_r))[cells.ravel()]**2)))
    motion = float(np.sqrt(np.mean((new_r-old_r).reshape(len(probes), len(GRID), 2)[cells.any(1), 0, 0]**2)))
    return np.array([gamma, motion]), dict(probe_count=len(probes), supported_cells=int(cells.sum()),
        delta_gamma=gamma, delta_m=motion,
        definition='RND2 common_deltas: response RMS over state,w; reference RMS over state')


class RND2BranchLearner:
    """Full RA-GQ with own-history refresh and actual issued base-G receipts."""
    def __init__(self, model, history, *, path_id, refit_every=1,
                 q_evaluation="nearest", query_horizon=None):
        if not isinstance(model, RND2GQ) or model.auxiliary != 'full':
            raise ValueError('a fitted full RND2GQ is required')
        model._require_fitted()
        if isinstance(refit_every, bool) or not isinstance(refit_every, int) or refit_every < 1:
            raise ValueError('refit_every must be positive integer')
        if q_evaluation not in ('nearest', 'bellman'):
            raise ValueError("evaluation must be 'nearest' or 'bellman'")
        if query_horizon is not None:
            query_horizon = _positive_integer(query_horizon, 'remaining_horizon')
        self.model = deepcopy(model); self.history = history.copy(deep=True)
        self.path_id = int(path_id); self.refit_every = refit_every
        self.q_evaluation = q_evaluation; self.query_horizon = query_horizon
        self.start_time = model.as_of_; self.receipts = []; self.refit_audits = []; self.pending = None

    def prepare(self, time, state):
        if time < self.model.as_of_:
            raise ValueError('cannot run before fitted vintage')
        if time > self.model.as_of_ and (time-self.start_time) % self.refit_every == 0:
            candidate = deepcopy(self.model)
            try:
                candidate.update(self.history, as_of=time, window=self.model.window_)
            except ValueError as exc:
                if str(exc).startswith(('no common actual node at previous_action=', 'duplicate selection removed too many actual joint nodes')):
                    raise SupportError(str(exc)) from exc
                raise
            delta, audit = common_rnd2_deltas(self.model.base_model_, candidate.base_model_)
            state.auxiliary[:2] = delta
            self.refit_audits.append(dict(time=time, **audit))
            self.model = candidate
        return state

    def _q(self, state):
        if state.physical.shape != (3,) or state.auxiliary.shape != (3,):
            raise ValueError('RND2 requires state,w,previous_action and delta_gamma,delta_m,residual')
        return self.model.q_values(state.physical[None], state.auxiliary[None],
                                   remaining_horizon=getattr(self, 'query_horizon', None),
                                   evaluation=getattr(self, 'q_evaluation', 'nearest'))[0]

    def choose(self, time, state):
        q = self._q(state)
        if not np.isfinite(q).any():
            raise SupportError('no supported full RA-GQ action')
        return float(GRID[np.argmax(q)])

    def supported(self, time, state, action):
        match = np.flatnonzero(GRID == action)
        return bool(len(match) == 1 and np.isfinite(self._q(state)[match[0]]))

    def issue(self, time, state, action):
        if self.pending is not None:
            raise ValueError('previous forecast has not been released')
        base_prediction = self.model.base_model_.transition_.predict(state.physical[None], [action])[0]
        full_prediction = self.model.model_.transition_.predict(state.physical[None], [action], state.auxiliary[None])[0]
        base = float(base_prediction[0])
        full = float(full_prediction[0])
        q = self._q(state)
        record = dict(time=time, fit_as_of=self.model.as_of_, base_fit_as_of=self.model.as_of_, full_fit_as_of=self.model.as_of_,
                      q_values=[float(v) if np.isfinite(v) else None for v in q],
                      qualified_action_mask=np.isfinite(q).tolist(),
                      executed_action_q=float(q[np.flatnonzero(GRID==action)[0]]),
                      base_state_prediction=base,
                      full_state_prediction=full, action=action,
                      # Additive receipt fields: w is the observed proxy, not latent Z.
                      # Exact action memory is not an estimated physical response.
                      base_physical_prediction=base_prediction[:2].tolist(),
                      full_physical_prediction=full_prediction[:2].tolist(),
                      same_base_as_Q_kernel=True,
                      qualification='native_local_support_and_finite_Q', eta_status='not_supplied',
                      auxiliary_at_issue=state.auxiliary.tolist(),
                      active_auxiliaries=list(self.model.model_.transition_.active))
        self.pending = deepcopy(record)
        return record

    def observe(self, time, state, action, outcome):
        issued = self.pending
        if issued is None or issued['time'] != time or issued['action'] != action:
            raise ValueError('release lacks its issued forecast')
        if outcome.release_time != time+1 or outcome.next_physical[2] != action:
            raise ValueError('release must update previous_action to the executed action')
        x = state.physical; y = outcome.next_physical
        row = dict(path_id=self.path_id, period=time, release_period=time+1,
                   state=x[0], w=x[1], previous_action=x[2], action=action,
                   next_state=y[0], next_w=y[1], reward=outcome.reward,
                   delta_gamma=state.auxiliary[0], delta_m=state.auxiliary[1], residual=state.auxiliary[2],
                   residual_source_period=time-1, auxiliary_as_of=time)
        self.history = pd.concat([self.history, pd.DataFrame([row])], ignore_index=True)
        residual = float(y[0]-issued['base_state_prediction'])
        self.receipts.append(dict(**issued, release_time=time+1, actual_state=float(y[0]), residual=residual))
        self.pending = None
        return np.r_[state.auxiliary[:2], residual]


def prepare_rnd2_learner(history, *, as_of, warmup_as_of, window,
                         path_id, refit_every=1, beta=.95, horizon=3,
                         nodes_per_memory=5, noise_nodes=4,
                         q_evaluation="nearest", query_horizon=None):
    """Reconstruct public prefix auxiliaries, then fit actual full RND2 G/Q.

    Warmup forecasts are labeled reconstructed; online forecasts are issued
    before outcomes. Initial delta/residual are zero at warmup_as_of only.
    The caller supplies all released data; no fixture or environment is loaded.
    """
    as_of=_date(as_of,'as_of');warmup_as_of=_date(warmup_as_of,'warmup_as_of')
    window=_positive_integer(window,'window');path_id=_date(path_id,'path_id')
    if not warmup_as_of <= as_of-window:
        raise ValueError('warmup must precede as_of; positive window required')
    raw = history.copy(deep=True)
    required = XCOL + ['path_id','period','action','next_state','next_w','reward']
    if not set(required) <= set(raw):
        raise ValueError('missing RND2 public transition columns')
    if 'release_period' not in raw:
        raw['release_period'] = raw.period+1
    if (not np.isfinite(raw[['period','release_period']].to_numpy(float)).all()
        or not np.equal(raw.period,np.floor(raw.period)).all()
        or (raw.release_period != raw.period+1).any()) or raw.duplicated(['path_id','period']).any():
        raise ValueError('one-period unique public transitions required')
    # Future data are excluded before any reconstruction or probe selection.
    raw = raw.loc[raw.release_period <= as_of].sort_values(['period','path_id'],kind='stable').copy()
    if not np.isfinite(raw[required].to_numpy(float)).all():
        raise ValueError('public transitions must be finite')
    def fit_base(date):
        frame = raw.loc[(raw.period >= date-window)&(raw.period < date)&(raw.release_period <= date)]
        return _fit_model(frame)
    base = fit_base(warmup_as_of); delta=np.zeros(2); residuals={pid:0. for pid in raw.path_id.unique()}
    annotated=[]; audits=[]
    for time in range(warmup_as_of, as_of):
        rows=raw.loc[raw.period==time].copy()
        if rows.empty:
            raise ValueError('warmup requires released rows at each date')
        rows['delta_gamma']=delta[0];rows['delta_m']=delta[1];rows['residual']=rows.path_id.map(residuals)
        rows['residual_source_period']=time-1;rows['auxiliary_as_of']=time
        issued=base.transition_.predict(rows[XCOL].to_numpy(float),rows.action.to_numpy(float))[:,0]
        residuals.update(zip(rows.path_id,rows.next_state.to_numpy(float)-issued))
        annotated.append(rows);new=fit_base(time+1);delta,audit=common_rnd2_deltas(base,new)
        audits.append(dict(time=time+1,provenance='reconstructed_prefix_not_live_forecast',**audit));base=new
    frame=pd.concat(annotated,ignore_index=True)
    model=RND2GQ('full',beta=beta,horizon=horizon,nodes_per_memory=nodes_per_memory,noise_nodes=noise_nodes).fit(frame,as_of=as_of,window=window)
    # The warmup's final base vintage must be the base used by full Q's residual successor.
    np.testing.assert_allclose(base.core._C,model.base_model_.core._C,rtol=0,atol=1e-10)
    np.testing.assert_allclose(base.core._Psi,model.base_model_.core._Psi,rtol=0,atol=1e-10)
    last=raw.loc[raw.path_id==path_id].sort_values('period').iloc[-1]
    if last.period != as_of-1:
        raise ValueError('target path must have a final prefix release at as_of')
    state=PublicState(np.array([last.next_state,last.next_w,last.action]),np.r_[delta,residuals[path_id]])
    learner=RND2BranchLearner(model,frame,path_id=path_id,refit_every=refit_every,
                            q_evaluation=q_evaluation,query_horizon=query_horizon)
    learner.refit_audits=audits
    return learner,state
