"""Self-contained HTML rendering for a saved two-stage report.

This module only formats the supplied report. It does not run the detector,
source evaluator, or any statistical procedure.
"""
from __future__ import annotations

import html
import json
from collections.abc import Mapping


def _esc(value) -> str:
    if value is None:
        return "<span class=\"unavailable\">未提供</span>"
    if isinstance(value, bool):
        value = "是" if value else "否"
    elif isinstance(value, (dict, list, tuple)):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)
    return html.escape(str(value), quote=True)


def _number(value, kind: str) -> str:
    if value is None:
        label = "未建立" if kind == "type_i" else "未估计"
        return f'<span class="unavailable">{label}</span>'
    return _esc(value)


def _error_rows(errors, *, include_targets=False) -> str:
    if not isinstance(errors, Mapping):
        return '<tr><td colspan="6">未提供错误率记录</td></tr>'
    rows = []
    for family, measures in errors.items():
        if not isinstance(measures, Mapping):
            continue
        for kind in ("type_i", "type_ii"):
            item = measures.get(kind)
            if not isinstance(item, Mapping):
                continue
            rows.append(
                "<tr>"
                f"<td>{_esc(family)}</td><td>{_esc(kind)}</td>"
                + (f"<td>{_esc(item.get('target'))}</td>" if include_targets else "")
                +
                f"<td>{_esc(item.get('conditioning'))}</td>"
                f"<td>{_number(item.get('target_budget'), kind)}</td>"
                f"<td>{_number(item.get('proved_bound'), kind)}</td>"
                f"<td>{_number(item.get('empirical'), kind)}</td>"
                "</tr>"
            )
    return "".join(rows) or '<tr><td colspan="6">未提供错误率记录</td></tr>'


def render_html(report) -> str:
    """Render a complete, dependency-free HTML document from a saved report."""
    if not isinstance(report, Mapping):
        raise TypeError("report must be a mapping")
    stage1 = report.get("stage1") or {}
    stage2 = report.get("stage2") or {}
    labels = report.get("source_labels") or {}
    disclosure = report.get("semantic_disclosure", "")
    context = report.get("context") or {}
    conditional = context.get("route") == "conditional_history_saved_report"
    source_probability = "不可用"
    encoded = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
    errors_table = _error_rows(report.get("errors"))
    if conditional:
        errors_table = _error_rows(report.get("errors"), include_targets=True)
        shared = (report.get("errors") or {}).get("joint", {}).get("resolved_assertion_error", {})
        errors_table += (
            '<tr><td>joint: resolved assertion (shared)</td><td>shared resolved error</td>'
            f'<td>{_esc(shared.get("target"))}</td>'
            f'<td>{_esc(shared.get("conditioning"))}</td>'
            f'<td>{_number(shared.get("target_budget"), "type_i")}</td>'
            f'<td>{_number(shared.get("proved_bound"), "type_i")}</td>'
            f'<td>{_number(shared.get("empirical"), "type_i")}</td></tr>')
    capacity = ""
    if "calibration_capacity_explanation" in stage1:
        capacity = (
            '<p>CAL 失败槽数：' + _esc(stage1.get("cal_failed_count")) +
            ' / ' + _esc(stage1.get("cal_total_B")) +
            '；失败槽给出的 p 值下界：' + _esc(stage1.get("calibration_failure_p_floor")) +
            '；仅从该下界看是否允许拒绝：' + _esc(stage1.get("calibration_allows_rejection")) +
            '。</p><p>' + _esc(stage1["calibration_capacity_explanation"]) + '</p>')
    if not conditional:
        return """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>两阶段诊断报告</title>
<style>
body{font:16px/1.5 system-ui,sans-serif;max-width:960px;margin:2rem auto;padding:0 1rem;color:#202124}
h1,h2{line-height:1.2} .unavailable{color:#7a4b00;font-weight:600}
table{border-collapse:collapse;width:100%;margin:1rem 0}th,td{border:1px solid #bbb;padding:.45rem;text-align:left;vertical-align:top}
th{background:#f2f4f7} pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f6f8fa;padding:1rem}
details{border-top:1px solid #bbb;margin-top:1.5rem;padding-top:.8rem} summary{cursor:pointer;font-weight:650}
</style>
</head>
<body>
<main>
<h1>两阶段诊断报告</h1>
<section aria-labelledby="conclusions"><h2 id="conclusions">结论</h2>
<p>第一层：<strong>""" + _esc(stage1.get("status")) + """</strong></p>
""" + capacity + """
<p>第二层：<strong>""" + _esc(stage2.get("outcome")) + """</strong>；
""" + _esc(labels.get("latent", "latent")) + """：""" + _esc(stage2.get("latent")) + """；""" + _esc(labels.get("model", "model")) + """：""" + _esc(stage2.get("model")) + """；
mixed：""" + _esc(stage2.get("mixed")) + """</p>
<p>""" + _esc(disclosure) + """</p>
<p>来源概率：<strong>""" + source_probability + """</strong>。来源必要性相对于已声明的候选类，不表示来源发生概率。</p>
</section>
<details><summary>Details</summary>
<section aria-labelledby="errors"><h2 id="errors">Type I / Type II 解释与数值</h2>
<p>检测 Type I：无变化时报警；检测 Type II：指定变化下到截止期仍未完成报警。
来源 Type I：该成分不变却报告其必要；来源 Type II：指定成分变化下未完成其必要性报告。
第二层口径条件于第一层已报警；mixed 为两项必要性报告同时成立。</p>
<p>下表区分预设预算、适用假设下的理论界和匹配实验估计。理论界不验证本次输入的假设，
浮点统计半径也不因精确集合证书而获得机器精确覆盖。未建立或未估计不等于零。</p>
<table><thead><tr><th>检验</th><th>类型</th><th>条件</th><th>目标预算</th><th>已证上界</th><th>匹配实验</th></tr></thead>
<tbody>""" + errors_table + """</tbody></table>
</section>
<h2>保存的完整报告</h2><pre>""" + html.escape(encoded, quote=True) + """</pre></details>
</main>
</body>
</html>
"""
    if conditional:
        conclusion = (
            '<p>第二层：<strong>' + _esc(stage2.get("outcome")) + '</strong>；'
            'model：' + _esc(stage2.get("model")) + '；latent：' + _esc(stage2.get("latent")) + '</p>'
            '<p>保留候选：<strong>' + _esc(stage2.get("retained")) + '</strong></p>'
            '<p>混合状态：<strong>' + _esc(stage2.get("mixed_status")) + '</strong>；'
            'mixed boolean（joint_presence_asserted_only）：<strong>' + _esc(stage2.get("mixed")) + '</strong>。'
            'false 不表示 mixed absent。</p>'
            '<p>错误范围：' + _esc(context.get("error_scope")) + '</p>')
        error_explanation = (
            '<p>来源 Type I 的目标仅是错误的 presence assertion；来源 Type II 未估计，'
            'unresolved/withheld 也不构成 presence assertion。joint shared resolved-assertion 字段列出同一项共享错误的目标，'
            '包括错误的 presence 或 absence assertion，不包括 unresolved 漏检。实际是否建立适用界见错误范围。</p>'
            '<p>错误范围：' + _esc(context.get("error_scope")) + '</p>'
            '<p>执行范围：' + _esc(context.get("execution_scope")) + '</p>')
        probability_explanation = '来源概率不可用；p 值是包含观测值的秩，不是后验概率。'
        table_header = '<tr><th>检验</th><th>类型</th><th>错误目标</th><th>条件</th><th>目标预算</th><th>已证上界</th><th>匹配实验</th></tr>'
    return """<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>两阶段诊断报告</title>
<style>
body{font:16px/1.5 system-ui,sans-serif;max-width:960px;margin:2rem auto;padding:0 1rem;color:#202124}
h1,h2{line-height:1.2} .unavailable{color:#7a4b00;font-weight:600}
table{border-collapse:collapse;width:100%;margin:1rem 0}th,td{border:1px solid #bbb;padding:.45rem;text-align:left;vertical-align:top}
th{background:#f2f4f7} pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f6f8fa;padding:1rem}
details{border-top:1px solid #bbb;margin-top:1.5rem;padding-top:.8rem} summary{cursor:pointer;font-weight:650}
</style>
</head>
<body>
<main>
<h1>两阶段诊断报告</h1>
<section aria-labelledby="conclusions"><h2 id="conclusions">结论</h2>
<p>第一层：<strong>""" + _esc(stage1.get("status")) + """</strong></p>
""" + capacity + conclusion + """
<p>""" + _esc(disclosure) + """</p>
<p>""" + probability_explanation + """</p>
</section>
<details><summary>Details</summary>
<section aria-labelledby="errors"><h2 id="errors">Type I / Type II 解释与数值</h2>
""" + error_explanation + """
<p>下表区分预设预算、适用假设下的理论界和匹配实验估计。理论界不验证本次输入的假设，
浮点统计半径也不因精确集合证书而获得机器精确覆盖。未建立或未估计不等于零。</p>
<table><thead>""" + table_header + """</thead>
<tbody>""" + errors_table + """</tbody></table>
</section>
<h2>保存的完整报告</h2><pre>""" + html.escape(encoded, quote=True) + """</pre></details>
</main>
</body>
</html>
"""


__all__ = ["render_html"]
